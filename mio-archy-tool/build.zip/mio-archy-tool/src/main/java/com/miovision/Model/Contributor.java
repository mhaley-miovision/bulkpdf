package com.miovision.Model;

/**
 * Created by vleipnik on 2015-08-31.
 */
public class Contributor extends MioarchyElement {
    private Employee employee;
    private Organization organization;
    private Role role;
    private Application application;
    private String accountabilityLabel;
    private String accountabilityLevel;

    public Contributor(int id, Employee employee, Organization organization, Role role, Application application,
                       String accountabilityLabel, String accountabilityLevel)
    {
        super(id, employee != null ? employee.name() : null);

        //TODO: add construction checks
        this.id = id;
        this.employee = employee;
        this.organization = organization;
        this.role = role;
        this.application = application;
        this.accountabilityLabel = accountabilityLabel;
        this.accountabilityLevel = accountabilityLevel;
    }

    public Employee employee() { return employee; }
    public Organization organization() {
        return organization;
    }
    public Application application() {
        return application;
    }
    public Role role() {
        return role;
    }
    public String accountabilityLabel() { return accountabilityLabel; }
    public String accountabilityLevel() { return accountabilityLevel; }
}

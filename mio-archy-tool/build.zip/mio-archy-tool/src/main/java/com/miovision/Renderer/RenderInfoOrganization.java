package com.miovision.Renderer;

import com.miovision.Model.Mioarchy;
import com.miovision.Model.Organization;

/**
 * Created by vleipnik on 2015-09-01.
 */
public class RenderInfoOrganization {

    private Organization org;
    private RenderInfoCircles circleInfo;

    public RenderInfoOrganization(Organization org, Mioarchy mioarchy) {
        this.org = org;

        // does org have children?

    }
}

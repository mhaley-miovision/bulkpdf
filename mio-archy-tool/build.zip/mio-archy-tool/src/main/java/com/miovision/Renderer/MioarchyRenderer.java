package com.miovision.Renderer;

import com.miovision.Model.Contributor;
import com.miovision.Model.Mioarchy;
import com.miovision.Model.Organization;
import com.miovision.Model.Role;
import com.mxgraph.io.mxCodec;
import com.mxgraph.util.mxCellRenderer;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxXmlUtils;
import com.mxgraph.view.mxGraph;
import org.w3c.dom.Document;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class MioarchyRenderer
{
    // Moves a list of points by dx,dy
    private Point[] translatePoints(Point[] points, double dx, double dy) {
        Point[] pointsTranslated = new Point[points.length];
        for (int i = 0; i < points.length; i++) {
            pointsTranslated[i] = new Point();
            pointsTranslated[i].setLocation(points[i].getX() + dx, points[i].getY() + dy);
        }
        return pointsTranslated;
    }

    // Draws equally sized and spaced circles
    private RenderInfoCircles calculateCircleLocations(int numCircles, double minDistanceBetweenCircles, double circleDiameter) {
        double dm = minDistanceBetweenCircles;
        double rc = circleDiameter / 2;
        int n = 0;
        int Nc = numCircles;
        int radiusIncrement = 1;
        int Nc_current = 0;
        int Nc_remaining = Nc;
        double x = 0;
        double y = 0;
        double width = 0;
        double height = 0;
        double minx = Double.MAX_VALUE;
        double miny = Double.MAX_VALUE;
        double maxx = Double.MIN_VALUE;
        double maxy = Double.MIN_VALUE;

        // base cases
        if (numCircles <= 0) {
            return new RenderInfoCircles(0, 0, new Point[] { });
        }
        if (numCircles == 1) {
            return new RenderInfoCircles(rc, rc, new Point[]{new Point(0, 0)});
        }

        Point[] circleCenters = new Point[numCircles];
        double R;
        double alpha_min;
        double alpha;

        while (Nc_remaining > 0) {
            // calculate current radius for this iteration
            R = radiusIncrement * (2 * rc + dm);

            // how many circles do we need to fit on the outer edge?
            alpha_min = 2 * Math.atan((rc + dm / 2) / R);

            // use remaining number of circles to see if they would all fit
            alpha = 2 * Math.PI / Nc_remaining;
            if (alpha < alpha_min) {
                // we have too many circles - so just use alpha min to determine the number of circles
                Nc_current = 1 + (int) Math.floor(2 * Math.PI / alpha_min);
                alpha = 2 * Math.PI / Nc_current; // override alpha in case of error due to approximation used
            } else {
                Nc_current = Nc_remaining;
            }

            // now draw the # of circles, given alpha
            for (int i = 0; i < Nc_current; i++) {
                double angle = alpha * i;
                double newX = x + R * Math.cos(angle);
                double newY = y + R * Math.sin(angle);
                Point p = new Point();
                p.setLocation(newX, newY);
                circleCenters[n++] = p;

                // update boundaries, accounting for circle radius
                maxx = Math.max(maxx, newX + rc);
                maxy = Math.max(maxy, newY + rc);
                minx = Math.min(minx, newX - rc);
                miny = Math.min(miny, newY - rc);
            }

            // increase to next radius for next iteration
            radiusIncrement++;
            Nc_remaining -= Nc_current;
        }
        // calculate bounding box
        width = maxx - minx;
        height = maxy - miny;

        return new RenderInfoCircles(width, height, circleCenters);
    }

    public String determineContributorColor(Contributor c, Mioarchy mioarchy)
    {
        String colorString = "";

        // this is a lead
        if (c.role().name().toLowerCase().indexOf("lead") >= 0) {
            colorString += "dark";
        }

        // by app now
        if (c.application() != null) {
            if (c.application().name().toLowerCase().indexOf("product") >= 0) {
                colorString = "green";
            } else if (c.application().name().toLowerCase().indexOf("strategic") >= 0) {
                colorString = "red";
            } else if (c.application().name().toLowerCase().indexOf("innovation") >= 0) {
                colorString = "gray";
            } else if (c.application().name().toLowerCase().indexOf("organizational development") >= 0) {
                colorString = "yellow";
            } else if (c.application().name().toLowerCase().indexOf("culture committee") >= 0) {
                colorString = "pink";
            } else if (c.application().name().toLowerCase().indexOf("quality control") >= 0) {
                colorString = "magenta";
            }
        } else {
            // try by organization
            if (c.organization() != null) {
                if (mioarchy.isDescendantOfOrganization(c.organization(), mioarchy.organizationByName("Engineering"))) {
                    colorString = "purple";
                } else if (mioarchy.isDescendantOfOrganization(c.organization(), mioarchy.organizationByName("Finance"))) {
                    colorString = "orange";
                } else if (mioarchy.isDescendantOfOrganization(c.organization(), mioarchy.organizationByName("Operations"))) {
                    colorString = "blue";
                }
            } else {
                colorString = "white";
            }
        }
        return colorString;
    }

    public void test(Mioarchy mioarchy) {

        System.out.println("Rendering Mioarchy...");

        //SAXParserFactory parserFactory = SAXParserFactory.newInstance();
        String inFile = "/Users/vleipnik/Downloads/input.xml";
        String outFile = "/Users/vleipnik/Downloads/output.xml";
        String outImage = "/Users/vleipnik/Downloads/output.png";

        try {
            mxGraph graph = new mxGraph();

            // Parses XML into graph
            Document doc = mxXmlUtils.parseXml(mxUtils.readFile(inFile));
            mxCodec codec = new mxCodec(doc);
            //codec.decode(doc.getDocumentElement(), graph.getModel());
            codec.decode(doc, graph.getModel());

            graph.getModel().beginUpdate();
            try {
                Object parent = graph.getDefaultParent();
                Object v1, v2, e1;
                v1 = null;
                v2 = null;

                final double CIRCLE_DIAMETER = 45;
                final double MIN_DISTANCE_BETWEEN_CIRCLES = 40;

                // take the top level org
                Organization testOrg = mioarchy.organizationByName("Miovision");
                List<Contributor> contribs = mioarchy.getOrganizationContributors(testOrg, true);

                // contributors = circles
                int numCircles = contribs.size();

                RenderInfoCircles circles = calculateCircleLocations(numCircles, MIN_DISTANCE_BETWEEN_CIRCLES, CIRCLE_DIAMETER);
                Point[] circleLocations = translatePoints(circles.circleCenters(), 400, 400);

                for (int i = 0; i < numCircles; i++) {

                    String defaultStyle = "ellipse;whiteSpace=wrap;html=1;gradientColor=none";
                    String color = determineContributorColor(contribs.get(i), mioarchy);
                    double defaultWidth = CIRCLE_DIAMETER;
                    double defaultHeight = CIRCLE_DIAMETER;

                    double x = circleLocations[i].x;
                    double y = circleLocations[i].y;

                    String label;
                    if (contribs.get(i).employee() != null) {
                        label = contribs.get(i).employee().shortName().toLowerCase();
                    } else {
                        label = "<NEW>"; // not yet hired
                    }

                    v2 = v1;
                    v1 = graph.insertVertex(parent, null, label, x, y, defaultWidth, defaultHeight, defaultStyle + ";" + color);

                    /*
                    if (i > 1)
                        e1 = graph.insertEdge(parent, null, "e1", v1, v2);
                       */

                }

            } finally {
                graph.getModel().endUpdate();
            }

            BufferedImage image = mxCellRenderer.createBufferedImage(graph, null,
                    1, Color.WHITE, true, null);
            java.io.File file = new File(outImage);
            ImageIO.write(image, "png", file);

            mxUtils.writeFile(mxXmlUtils.getXml(codec.encode(graph.getModel())), outFile);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Finished rendering!");
    }
}

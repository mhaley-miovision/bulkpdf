package com.miovision.Model;

/**
 * Created by vleipnik on 2015-08-31.
 */
public class Role extends MioarchyElement {
    public Role(int id, String name) {
        super(id, name);
    }
}
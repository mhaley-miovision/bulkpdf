package com.miovision.Renderer;

import java.awt.*;

/**
 * Created by vleipnik on 2015-09-01.
 */
public class RenderInfoCircles extends RenderInfo {

    protected Point[] circleCenters;

    public RenderInfoCircles(double width, double height, Point[] circleCenters) {
        super (width, height);
        this.circleCenters = circleCenters;
    }

    public Point[] circleCenters() {
        return circleCenters;
    }
}

package com.miovision.Model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by vleipnik on 2015-09-01.
 */
public class Mioarchy {
    // lists
    private List<Contributor> contributors;

    // maps
    private HashMap<String, Organization> organizationsByName;
    private HashMap<String, Contributor> contributorsByName;
    private HashMap<String, Employee> employeesByName;
    private HashMap<String, Application> applicationsByName;
    private HashMap<String, Role> rolesByName;

    public Mioarchy(List<Contributor> contributors,
                    HashMap<String, Organization> organizationsByName,
                    HashMap<String, Contributor> contributorsByName,
                    HashMap<String, Employee> employeesByName,
                    HashMap<String, Application> applicationsByName,
                    HashMap<String, Role> rolesByName) {
        this.contributors = contributors;
        this.applicationsByName = applicationsByName;
        this.employeesByName = employeesByName;
        this.rolesByName = rolesByName;
        this.contributorsByName = contributorsByName;
        this.organizationsByName = organizationsByName;
    }



    public Organization[] organizationsByName() {
        Organization[] organizationsArray = new Organization[organizationsByName.size()];
        return organizationsByName.values().toArray(organizationsArray);
    }

    public Contributor[] contributorsByName() {
        Contributor[] contributorsArray = new Contributor[contributorsByName.size()];
        return contributorsByName.values().toArray(contributorsArray);
    }

    public Employee[] employeesByName() {
        Employee[] employeesArray = new Employee[employeesByName.size()];
        return employeesByName.values().toArray(employeesArray);
    }

    public Application[] applicationsByName() {
        Application[] applicationsArray = new Application[applicationsByName.size()];
        return applicationsByName.values().toArray(applicationsArray);
    }

    public Role[] rolesByName() {
        Role[] rolesArray = new Role[rolesByName.size()];
        return rolesByName.values().toArray(rolesArray);
    }

    public Application applicationByName(String name) {
        return applicationsByName.get(name);
    }
    public Employee employeeByName(String name) {
        return employeesByName.get(name);
    }
    public Role roleByName(String name) {
        return rolesByName.get(name);
    }
    public Contributor contributorByName(String name) {
        return contributorsByName.get(name);
    }
    public Organization organizationByName(String name) {
        return organizationsByName.get(name);
    }

    public List<Organization> getOrganizationChildren(Organization organization) {
        List<Organization> children = new ArrayList<>();
        for (Organization o : organizationsByName.values()) {
            // equality judged on name
            if (o.parent() != null) {
                if (o.parent().name().equalsIgnoreCase(organization.name())) {
                    children.add(o);
                }
            }
        }
        return children;
    }

    public List<Contributor> getOrganizationContributors(Organization organization, boolean recurse) {
        List<Contributor> list = new ArrayList<>();
        // contributors at sub levels
        if (recurse) {
            for (Organization o : getOrganizationChildren(organization)) {
                list.addAll(getOrganizationContributors(o, true));
            }
        }
        // contributors at this level
        for (Contributor c : contributors) {
            if (c.organization() != null) {
                if (c.organization().name().equalsIgnoreCase(organization.name())) {
                    list.add(c);
                }
            }
        }
        return list;
    }

    public boolean isDescendantOfOrganization(Organization testSubject, Organization desiredParent) {
        if (testSubject.parent() == null || testSubject.parent().name() == null || desiredParent == null || desiredParent.name() == null)
            return false;

        if (testSubject.parent().name().equalsIgnoreCase(desiredParent.name()))
            return true;

        return isDescendantOfOrganization(testSubject.parent(), desiredParent);
    }
}
sudo ssh -i ~/keys/vic-deploy-key.pem ubuntu@ec2-54-152-211-94.compute-1.amazonaws.com
